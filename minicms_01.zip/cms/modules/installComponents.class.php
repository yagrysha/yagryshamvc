<?php
/**
 * yagrysha@gmail.com
 * Yaroslav Gryshanovich
 * http://mvc.yagrysha.com/
 */
class installComponents extends Components {

	var $moduleName = 'install';

	function indexAction(){
		if (version_compare(phpversion(), '4.3.1', '<')===true) {
			$this->response['error'] = 'Ваша версия PHP '. phpversion().' <span style="color:red;">Необходима версия 4.3 и выше.';
			return false;
		}

		if(@$_REQUEST['step']==1){
			if(!$_REQUEST['domain']){
				$this->response['error'] = 'Укажите домен';
				return false;
			}
			if(!$_REQUEST['database']){
				$this->response['error'] = 'Выберите базу данных';
				return false;
			}
			if(!$_REQUEST['dbname']){
				$this->response['error'] = 'Укажите имя базы данных';
				return false;
			}
			if(!$_REQUEST['dbhost']){
				$this->response['error'] = 'Укажите хост';
				return false;
			}
			if(!$_REQUEST['dbuser']){
				$this->response['error'] = 'Укажите пользователя базы даннх';
				return false;
			}
			if(!$_REQUEST['login']){
				$this->response['error'] = 'Укажите логин администратора';
				return false;
			}
			if(!$_REQUEST['password']){
				$this->response['error'] = 'Укажите пароль администратора';
				return false;
			}
			if(!$_REQUEST['email']){
				$this->response['error'] = 'Укажите email администратора';
				return false;
			}
			if(!is_writable(CONFIG_DIR.'conf.php')){
				$this->response['error'] = 'conf.php недоступен для записи.';
				return false;
			}
			$sql = file_get_contents(ROOT_DIR.'/cms.sql');
			$sql = str_replace(array('#ADMINLOGIN#', '#ADMINPASSWORD#', '#ADMINEMAIL#', '#TIME#'), array($_REQUEST['login'], md5($_REQUEST['password']), $_REQUEST['email'], time()), $sql);
			$sql = str_replace(array('#SITEDESCRIPTION#', '#SITEKEYWORDS#', '#SITENAME#', '#SITETITLE#'), array($_REQUEST['site_description'], $_REQUEST['site_keywords'], $_REQUEST['site_name'], $_REQUEST['site_title']), $sql);
			$sql = explode(';',$sql);
			if($_REQUEST['database']=='mysql'){
				include_once(INCDB_DIR.'mysql.class.php');
				$db = new Mysql();
				$db->dbhost = $_REQUEST['dbhost'];
				$db->dbuser = $_REQUEST['dbuser'];
				$db->dbpassw = $_REQUEST['dbpassword'];
				$db->dbname = $_REQUEST['dbname'];
				$db->connect();
			}elseif ($_REQUEST['database']=='sqlite'){
				include_once(INCDB_DIR.'sqlite.class.php');
				$db = new Sqlite();
				$db->dbname = $_REQUEST['dbname'];
				$db->connect();
			}else{
				$this->response['error'] = 'db Error';
				return false;
			}
			foreach ($sql as $s){
				@$db->sql(trim($s, "\n\r\t "));
			}
			$conf = file_get_contents(CONFIG_DIR.'conf.php');
			$conf = preg_replace('/"DOMAINN", "[^"]*"/', '"DOMAINN", "'.trim($_REQUEST['domain']).'"', $conf);
			$conf = preg_replace('/"DBCLASS", "[^"]*"/', '"DBCLASS", "'.trim($_REQUEST['database']).'"', $conf);
			$conf = preg_replace('/"DBHOST",  "[^"]*"/', '"DBHOST",  "'.trim($_REQUEST['dbhost']).'"', $conf);
			$conf = preg_replace('/"DBUSER",  "[^"]*"/', '"DBUSER",  "'.trim($_REQUEST['dbuser']).'"', $conf);
			$conf = preg_replace('/"DBPASSW", "[^"]*"/', '"DBPASSW", "'.trim($_REQUEST['dbpassword']).'"', $conf);
			$conf = preg_replace('/"DBNAME",  "[^"]*"/', '"DBNAME",  "'.trim($_REQUEST['dbname']).'"', $conf);
			file_put_contents(CONFIG_DIR.'conf.php', $conf);
			$this->response['ok'] = 1;
		}
	}
}