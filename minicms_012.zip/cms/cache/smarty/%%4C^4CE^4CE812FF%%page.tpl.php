<?php /* Smarty version 2.6.22, created on 2009-03-18 16:39:10
         compiled from D:%5Cxampp%5Chtdocs%5Ccms/templates/page/page.tpl */ ?>
			<div id="content">
				<div class="post">
					<h2 class="title"><?php echo $this->_tpl_vars['page']['name']; ?>
</h2>
					<div class="entry"><?php echo $this->_tpl_vars['page']['text']; ?>
</div>
				</div>
			</div>