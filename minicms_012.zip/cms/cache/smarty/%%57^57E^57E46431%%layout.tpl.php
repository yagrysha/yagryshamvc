<?php /* Smarty version 2.6.22, created on 2009-03-18 16:39:09
         compiled from D:%5Cxampp%5Chtdocs%5Ccms/templates/layout.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'include_component', 'D:\\xampp\\htdocs\\cms/templates/layout.tpl', 18, false),)), $this); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="description" content="<?php if ($this->_tpl_vars['page']['description']): ?><?php echo $this->_tpl_vars['page']['description']; ?>
<?php else: ?><?php echo $this->_tpl_vars['_conf']['site_description']; ?>
<?php endif; ?>" />
<meta name="keywords" content="<?php if ($this->_tpl_vars['page']['keywords']): ?><?php echo $this->_tpl_vars['page']['keywords']; ?>
<?php else: ?><?php echo $this->_tpl_vars['_conf']['site_keywords']; ?>
<?php endif; ?>" />
<meta name="generator" content="miniCMS">
<title><?php if ($this->_tpl_vars['page']['title']): ?><?php echo $this->_tpl_vars['page']['title']; ?>
<?php else: ?><?php echo $this->_tpl_vars['_conf']['site_title']; ?>
<?php endif; ?></title>
<link rel="stylesheet" type="text/css"  href="/css/style.css" />
</head>
<body>
<div id="wrapper">
	<div id="wrapper2">
		<div id="header">
			<div id="logo">
				<h1><?php echo $this->_tpl_vars['_conf']['site_name']; ?>
</h1>
			</div>
			<?php echo smarty_function_include_component(array('name' => "page/mainmenu"), $this);?>

		</div>
		<!-- end #header -->
		<div id="page">
		<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => $this->_tpl_vars['template'], 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
			<!-- end #content -->
			<div id="sidebar">
				<ul>
				<?php echo smarty_function_include_component(array('name' => "page/rightblock"), $this);?>

				<?php echo smarty_function_include_component(array('name' => "page/rightmenu",'id' => $this->_tpl_vars['page']['id'],'pid' => $this->_tpl_vars['page']['pid']), $this);?>
	
				</ul>
			</div>
			<!-- end #sidebar -->
			<div style="clear: both;">&nbsp;</div>
		</div>
		<!-- end #page -->
	</div>
	<!-- end #wrapper2 -->
	<div id="footer">
		<p>(c) 2009 <?php echo @DOMAINN; ?>
</p>
	</div>
</div>
<!-- end #wrapper -->
</body>
</html>