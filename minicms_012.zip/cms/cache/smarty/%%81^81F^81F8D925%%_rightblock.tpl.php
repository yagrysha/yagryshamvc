<?php /* Smarty version 2.6.22, created on 2009-03-18 16:39:09
         compiled from D:%5Cxampp%5Chtdocs%5Ccms/templates/page/_rightblock.tpl */ ?>
<?php if ($this->_tpl_vars['page']): ?><li>
<h3><?php echo $this->_tpl_vars['page']['title']; ?>
</h3>
<?php echo $this->_tpl_vars['page']['text']; ?>

</li><?php endif; ?>