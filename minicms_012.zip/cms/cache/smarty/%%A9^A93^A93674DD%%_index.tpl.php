<?php /* Smarty version 2.6.22, created on 2009-03-18 16:38:21
         compiled from D:%5Cxampp%5Chtdocs%5Ccms/templates/install/_index.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'default', 'D:\\xampp\\htdocs\\cms/templates/install/_index.tpl', 48, false),)), $this); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Install</title>
<meta name="description" content="minimvc 404 page" />
<meta name="keywords" content="minimvc" />
<link href="/css/style.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<body>
<div id="wrapper">
	<div id="wrapper2">
		<div id="header">
			<div id="logo">
				<h1>minimvc</h1>
			</div>
			<div id="menu">
				<ul>
				</ul>
			</div>
		</div>
		<!-- end #header -->
		<div id="page">
			<div id="content" style="width:95%;">
				<div class="post">
<h2>Установка</h2>
<?php if ($this->_tpl_vars['phpversion']): ?></span><?php endif; ?>
<?php if ($this->_tpl_vars['ok']): ?>
Устновка завершена.<br />

<strong>Удалите файл install.php</strong>

<?php else: ?>
<form action="install.php" method="post">
<input type="hidden" name="step" value="1">
<table width="100%">
<tr><td><strong></strong></td><td><?php if ($this->_tpl_vars['error']): ?><strong style="color:red;"><?php echo $this->_tpl_vars['error']; ?>
</strong><?php endif; ?></td></tr>
<tr><td>Домен (site.com)</td><td><input type="text" size="60" name="domain" value="<?php echo $_POST['domain']; ?>
"></td></tr>
<tr><td>Название</td><td><input type="text" name="site_name" size="90" value="<?php echo $_POST['site_name']; ?>
"></td></tr>
<tr><td>Заголовок (title)</td><td><input type="text" name="site_title" size="90" value="<?php echo $_POST['site_title']; ?>
"></td></tr>
<tr><td>Описание (meta description)</td><td><input type="text" size="90" name="site_description" value="<?php echo $_POST['site_description']; ?>
"></td></tr>
<tr><td>Ключевые слова (meta keywords)</td><td><input type="text" size="90" name="site_keywords" value="<?php echo $_POST['site_keywords']; ?>
"></td></tr>

<tr><td><strong>База данных</strong></td><td><select name="database">
<option value=""> Выберите </option>
<option value="mysql"<?php if ($_POST['database'] == 'mysql'): ?> selected<?php endif; ?>>MySql</option>
<option value="sqlite"<?php if ($_POST['database'] == 'sqlite'): ?> selected<?php endif; ?>>SQLite</option></select></td></tr>
<tr><td>База данных</td><td><input type="text" name="dbname" size="60" value="<?php echo ((is_array($_tmp=@$_POST['dbname'])) ? $this->_run_mod_handler('default', true, $_tmp, 'minimvc') : smarty_modifier_default($_tmp, 'minimvc')); ?>
"></td></tr>
<tr><td>Хост</td><td><input type="text" name="dbhost" size="60" value="<?php echo ((is_array($_tmp=@$_POST['dbhost'])) ? $this->_run_mod_handler('default', true, $_tmp, 'localhost') : smarty_modifier_default($_tmp, 'localhost')); ?>
"></td></tr>
<tr><td>Пользователь</td><td><input type="text" name="dbuser" size="60" value="<?php echo ((is_array($_tmp=@$_POST['dbuser'])) ? $this->_run_mod_handler('default', true, $_tmp, 'root') : smarty_modifier_default($_tmp, 'root')); ?>
"></td></tr>
<tr><td>Пароль</td><td><input type="text" name="dbpassword" size="60" value="<?php echo $_POST['dbpassword']; ?>
"></td></tr>
<tr><td>Префикс</td><td><input type="text" name="prefix" size="60" value="<?php echo ((is_array($_tmp=@$_POST['prefix'])) ? $this->_run_mod_handler('default', true, $_tmp, 'ymc') : smarty_modifier_default($_tmp, 'ymc')); ?>
"></td></tr>

<tr><td><strong>Администратор</strong></td><td></td></tr>
<tr><td>Логин</td><td><input type="text" name="login" size="60" value="<?php echo ((is_array($_tmp=@$_POST['login'])) ? $this->_run_mod_handler('default', true, $_tmp, 'admin') : smarty_modifier_default($_tmp, 'admin')); ?>
"></td></tr>
<tr><td>Пароль</td><td><input type="text" name="password" size="60" value="<?php echo ((is_array($_tmp=@$_POST['password'])) ? $this->_run_mod_handler('default', true, $_tmp, 'admin') : smarty_modifier_default($_tmp, 'admin')); ?>
"></td></tr>
<tr><td>Email</td><td><input type="text" name="email" size="60" value="<?php echo ((is_array($_tmp=@$_POST['email'])) ? $this->_run_mod_handler('default', true, $_tmp, 'admin@nomail.ru') : smarty_modifier_default($_tmp, 'admin@nomail.ru')); ?>
"></td></tr>
<tr><td></td><td><input type="submit" value="Install"></td></tr>
</table>
</form><?php endif; ?>
				</div>
			</div>
			<!-- end #content -->
			<div style="clear: both;">&nbsp;</div>
			
		</div>
		<!-- end #page -->
	</div>
	<!-- end #wrapper2 -->
	<div id="footer">
		<p></p>
	</div>
</div>
<!-- end #wrapper -->
</body>
</html>