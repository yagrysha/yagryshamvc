<?php /* Smarty version 2.6.22, created on 2009-03-18 16:39:09
         compiled from D:%5Cxampp%5Chtdocs%5Ccms/templates/page/_mainmenu.tpl */ ?>
			<div id="menu">
				<ul>
					<li><a href="/">Homepage</a></li>
					<?php $_from = $this->_tpl_vars['menu']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['i']):
?>
						<li><a href="/<?php echo $this->_tpl_vars['i']['alias']; ?>
.html"><?php echo $this->_tpl_vars['i']['name']; ?>
</a></li>
					<?php endforeach; endif; unset($_from); ?>
				</ul>
			</div>