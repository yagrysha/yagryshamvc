/**
 * miniCMS 0.1.2 miniMVC 0.3.3  18.03.2009
 * @author Yaroslav Gryshanovich <yagrysha@gmail.com>
 * @link http://mvc.yagrysha.com/
 */
Использование скрипта

1. Загрузите файлы в свою директорию на web сервере.
2. Права на запись для:
	/config/conf.php
	/cache
	/cache/smarty
	/cache/components
	/userfiles
	/data/sqlite - если используете sqlite
3. Запустите install.php
После установки файл install.php нужно удалить.

Панель управления /admin/
Логин и пароль указанные при установке.

Со всеми вопросами, предложениями обращайтесь на e-mail