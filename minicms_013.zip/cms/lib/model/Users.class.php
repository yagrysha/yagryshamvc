<?php
/**
 * miniMVC 
 * http://mvc.yagrysha.com/
 */
class Users extends Item {
	var $table = 'users';

	function login($login, $passw){
		$u = $this->db->SelectOne($this->table, 
				array('where'=>'login="' . $login . '" AND password="'.md5($passw).'" AND type>0'));
		if(!$u) return false;
		$_SESSION['user'] = $u;
		$this->update($u['id'], array('last_login'=>time()));
		return $u;
	}

	function getByLogin($login){
		return $this->getItem(array('login'=>$login));
	}

	function getByEmail($mail){
		return $this->getItem(array('mail'=>$mail));
	}
}