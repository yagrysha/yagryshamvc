<?php
/**
 * miniCMS
 * http://mvc.yagrysha.com/
 */
class installComponents extends Components {

	var $moduleName = 'install';

	function indexAction(){
	    $this->response['phpversion'] = phpversion();
		if (version_compare($this->response['phpversion'], '4.4', '<')===true) {
			$this->response['error'] = 'Ваша версия PHP '. $this->response['phpversion'].' <span style="color:red;">Необходима версия 4.4 и выше.';
			return false;
		}

		if(@$_REQUEST['step']==1){
			if(!$_REQUEST['domain']){
				$this->response['error'] = 'Укажите домен';
				return false;
			}
			if(!$_REQUEST['database']){
				$this->response['error'] = 'Выберите базу данных';
				return false;
			}
			if(!$_REQUEST['dbname']){
				$this->response['error'] = 'Укажите имя базы данных';
				return false;
			}
			if(!$_REQUEST['dbhost'] && $_REQUEST['database']=='mysql'){
				$this->response['error'] = 'Укажите хост';
				return false;
			}
			if(!$_REQUEST['dbuser'] && $_REQUEST['database']=='mysql'){
				$this->response['error'] = 'Укажите пользователя базы даннх';
				return false;
			}
			if(!$_REQUEST['login']){
				$this->response['error'] = 'Укажите логин администратора';
				return false;
			}
			if(!$_REQUEST['password']){
				$this->response['error'] = 'Укажите пароль администратора';
				return false;
			}
			if(!$_REQUEST['email']){
				$this->response['error'] = 'Укажите email администратора';
				return false;
			}
			if(!is_writable(CONFIG_DIR.'conf.php')){
			    @chmod(CONFIG_DIR.'conf.php','777');
			    if(!is_writable(CONFIG_DIR.'conf.php')){
				    $this->response['error'] = '/config/conf.php недоступен для записи.';
				    return false;
			    }
			}
			
			if($_REQUEST['database']=='mysql'){
				$sql = file_get_contents(DATA_DIR.'cms.sql');
				include_once(INCDB_DIR.'mysql.class.php');
				$db = new Mysql();
				$db->dbhost = $_REQUEST['dbhost'];
				$db->dbuser = $_REQUEST['dbuser'];
				$db->dbpassw = $_REQUEST['dbpassword'];
				$db->dbname = $_REQUEST['dbname'];
				$db->connect();
			}elseif ($_REQUEST['database']=='sqlite'){
				$sql = file_get_contents(DATA_DIR.'cmsl.sql');
				@unlink(DATA_DIR.'sqlite/'.$_REQUEST['dbname']);
				include_once(INCDB_DIR.'sqlite.class.php');
				$db = new Sqlite();
				$db->dbname = $_REQUEST['dbname'];
				$db->connect();
			}else{
				$this->response['error'] = 'db Error';
				return false;
			}
			$sql = str_replace(array('#ADMINLOGIN#', '#ADMINPASSWORD#', '#ADMINEMAIL#', '#TIME#', '#PREFIX#'), array($_REQUEST['login'], md5($_REQUEST['password']), $_REQUEST['email'], time(), trim($_REQUEST['prefix'])), $sql);
			$sql = str_replace(array('#SITEDESCRIPTION#', '#SITEKEYWORDS#', '#SITENAME#', '#SITETITLE#'), array($_REQUEST['site_description'], $_REQUEST['site_keywords'], $_REQUEST['site_name'], $_REQUEST['site_title']), $sql);
			$sql = explode(';',$sql);
			foreach ($sql as $s){
				$ret = @$db->sql(trim($s, "\n\r\t "));
				
				if($_REQUEST['database']=='mysql' && mysql_errno()) {
				    $this->response['error'].= mysql_error().'<br />';
				}elseif ($_REQUEST['database']=='sqlite'){
				    $err = sqlite_error_string(sqlite_last_error($db->connection));
				    if($err && $err!='not an error') $this->response['error'].= $err.'<br />';
				}
				
				
			}
			$conf = file_get_contents(CONFIG_DIR.'conf.php');
			$domain = trim($_REQUEST['domain'], '/ ');
			$domain = str_replace(array('http://', 'https://'), '', $domain);
			if(strpos($domain, '/')){
				$conf = preg_replace('/"PATHFLDR", \d/', '"PATHFLDR", '.(int)substr_count($domain,'/'), $conf);
			}
			$conf = preg_replace('/"DOMAINN", "[^"]*"/', '"DOMAINN", "'.$domain.'"', $conf);
			$conf = preg_replace('/"DBCLASS", "[^"]*"/', '"DBCLASS", "'.trim($_REQUEST['database']).'"', $conf);
			$conf = preg_replace('/"DBHOST",  "[^"]*"/', '"DBHOST",  "'.trim(@$_REQUEST['dbhost']).'"', $conf);
			$conf = preg_replace('/"DBUSER",  "[^"]*"/', '"DBUSER",  "'.trim(@$_REQUEST['dbuser']).'"', $conf);
			$conf = preg_replace('/"DBPASSW", "[^"]*"/', '"DBPASSW", "'.trim(@$_REQUEST['dbpassword']).'"', $conf);
			$conf = preg_replace('/"DBNAME",  "[^"]*"/', '"DBNAME",  "'.trim(@$_REQUEST['dbname']).'"', $conf);
			$conf = preg_replace('/"DBPREFIX","[^"]*"/', '"DBPREFIX","'.trim(@$_REQUEST['prefix']).'"', $conf);
			file_put_contents(CONFIG_DIR.'conf.php', $conf);
			@chmod(CONFIG_DIR.'conf.php','644');
			$this->response['ok'] = 1;
		}
	}
}