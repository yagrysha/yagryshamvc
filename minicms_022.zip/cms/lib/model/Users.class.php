<?php
/**
 * miniCMS
 * http://mvc.yagrysha.com/
 */
class Users extends Item {
	var $table = 'users';

	function login($login, $passw){
		$u = $this->db->SelectOne($this->table, 
				array('where'=>'login="'.$this->db->esc($login).
                '" AND password="'.md5($passw).'" AND type>0'));
		if(!$u) return false;
		$_SESSION['user'] = $u;
		$this->update($u['id'], array('last_login'=>time()));
		return $u;
	}

	function signup($arr){
		$arr['type'] = 1;
		$arr['code'] = md5(uniqid(rand(1, 9), true));
		$arr['created_at'] = time();
		return $this->add($arr);
	}

	function getByLogin($login){
		return $this->getItem(array('login'=>$this->db->esc($login)));
	}

	function getByEmail($mail){
		return $this->getItem(array('mail'=>$this->db->esc($mail)));
	}

	function confirmEmail($code){
        $code = $this->db->esc($code);
		$user = $this->getItem(array('code'=>$code));
		if(!$user) return false;
		return $this->wupdate(
				array('type'=>'user', 'code'=>md5(uniqid(rand(1, 9), true))), 
				array('code'=>$code));
	}
}