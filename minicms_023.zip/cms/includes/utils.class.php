<?php
/**
 * miniMVC
 * http://mvc.yagrysha.com/
 */
class Utils {

    function getmicrotime() {
        list($usec, $sec) = explode(" ", microtime());
        return ((float)$usec + (float)$sec);
    }

    function location($url) {
        header('Location: ' . $url);
        exit();
    }

    function redirect($url) {
        header('Location: ' . DOMAIN .ROOT. $url);
        exit();
    }

    function getPages($count, $npage, $onpage = 20, $nn = 10) {
        $lastpage = ceil($count / $onpage);
        $end = ceil($npage / $nn) * $nn;
        $start = $end - ($nn - 1);
        $end = ($end > $lastpage)? $lastpage:$end;
        $pages = array();
        if($start > 1) $pages[$start - 1] = '...';
        for($i = $start; $i <= $end; $i++) {
            $pages[$i] = $i;
        }
        if($end < $lastpage) $pages[$end + 1] = '...';
        return $pages;
    }

    function disabmagquotes() {
        if (get_magic_quotes_gpc()) {
            $process = array(&$_GET, &$_POST, &$_COOKIE, &$_REQUEST);
            while (list($key, $val) = each($process)) {
                foreach ($val as $k => $v) {
                    unset($process[$key][$k]);
                    if (is_array($v)) {
                        $process[$key][stripslashes($k)] = $v;
                        $process[] = &$process[$key][stripslashes($k)];
                    } else {
                        $process[$key][stripslashes($k)] = stripslashes($v);
                    }
                }
            }
            unset($process);
        }
    }

    function makeUrlFriendly($input) {
        $output = substr($input, 0, 240);
        $output = strtolower($output);
        $output = trim($output);
        $output = html_entity_decode(htmlentities($output, ENT_COMPAT, 'UTF-8'));
        $output = preg_replace("/\s/", "-", $output);
        $output = str_replace("--", "-", $output);
        $output = str_replace("/", "", $output);
        $output = str_replace("\\", "", $output);
        $output = str_replace("'", "", $output);
        $output = str_replace(",", "", $output);
        $output = str_replace(";", "", $output);
        $output = str_replace(":", "", $output);
        $output = str_replace(".", "-", $output);
        $output = str_replace("?", "", $output);
        $output = str_replace("=", "-", $output);
        $output = str_replace("+", "", $output);
        $output = str_replace("$", "", $output);
        $output = str_replace("&", "", $output);
        $output = str_replace("!", "", $output);
        $output = str_replace(">>", "-", $output);
        $output = str_replace(">", "-", $output);
        $output = str_replace("<<", "-", $output);
        $output = str_replace("<", "-", $output);
        $output = str_replace("*", "", $output);
        $output = str_replace(")", "", $output);
        $output = str_replace("(", "", $output);
        $output = str_replace("[", "", $output);
        $output = str_replace("]", "", $output);
        $output = str_replace("^", "", $output);
        $output = str_replace("%", "", $output);
        $output = str_replace("»", "-", $output);
        $output = str_replace("|", "", $output);
        $output = str_replace("#", "", $output);
        $output = str_replace("@", "", $output);
        $output = str_replace("`", "", $output);
        $output = str_replace("”", "", $output);
        $output = str_replace("“", "", $output);
        $output = str_replace("\"", "", $output);
        $output = str_replace("_", "-", $output);
        $output = urlencode($output);
        return $output;
    }

    function translit($input) {
        $trans=array(
                "А" => "A",
                "Б" => "B",
                "В" => "V",
                "Г" => "G",
                "Д" => "D",
                "Е" => "E",
                "Ё" => "YO",
                "Ж" => "ZH",
                "З" => "Z",
                "И" => "I",
                "Й" => "J",
                "К" => "K",
                "Л" => "L",
                "М" => "M",
                "Н" => "N",
                "О" => "O",
                "П" => "P",
                "Р" => "R",
                "С" => "S",
                "Т" => "T",
                "У" => "U",
                "Ф" => "F",
                "Х" => "H",
                "Ц" => "TS",
                "Ч" => "CH",
                "Ш" => "SH",
                "Щ" => "SCH",
                "Ъ" => "",
                "Ы" => "Y",
                "Ь" => "",
                "Э" => "E",
                "Ю" => "YU",
                "Я" => "YA",
                "а" => "a",
                "б" => "b",
                "в" => "v",
                "г" => "g",
                "д" => "d",
                "е" => "e",
                "ё" => "yo",
                "ж" => "zh",
                "з" => "z",
                "и" => "i",
                "й" => "j",
                "к" => "k",
                "л" => "l",
                "м" => "m",
                "н" => "n",
                "о" => "o",
                "п" => "p",
                "р" => "r",
                "с" => "s",
                "т" => "t",
                "у" => "u",
                "ф" => "f",
                "х" => "h",
                "ц" => "ts",
                "ч" => "ch",
                "ш" => "sh",
                "щ" => "sch",
                "ъ" => "",
                "ы" => "y",
                "ь" => "",
                "э" => "e",
                "ю" => "yu",
                "я" => "ya",
                "№" => "No.",
                //ukranian symbols added
                'Ї' => 'I',
                'І' => 'I',
                'Є' => 'E',
                'ї' => 'i',
                'і' => 'i',
                'є' => 'e',
        );
        $input=strtr($input, $trans);
        return $input;
    }
}