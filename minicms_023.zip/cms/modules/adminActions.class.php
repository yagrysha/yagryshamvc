<?php
/**
 * miniCMS
 * http://mvc.yagrysha.com/
 */
class adminActions extends Actions {
	var $moduleName = 'admin';

	function adminActions(){
		include_once(MODEL_DIR.'Pages.class.php');
		parent::Actions();
		if($this->user['type']!=2) Utils::redirect('user/login.html');
		$this->nocache = true;
		$this->layout = 'admin';
		$this->u = new Users();
	}

	function indexAction(){}

	function adminsAction(){
		$where= array('type'=>2);
		$this->response['admins'] = $this->u->getItems(array('page'=>$this->request['page'], 'to'=>ITMP), $where);
		$count = $this->u->getCount($where);
		if ($count>sizeof($this->response['admins'])){
			$this->response['pager'] = Utils::getPages($count, $this->request['page'],ITMP);
		}
	}
	
	function addadminAction(){
		$this->view = '';
		if(empty($_POST['add']['login'])){
			$this->response['text'] = 'Пустой логин ';
			return false;
		}
		if($this->u->getByLogin($_POST['add']['login'])){
			$this->response['text'] = 'Логин занят';
			return false;
		}
		if(isset($_POST['add']['old_password'])){
			$_POST['add']['password'] = md5($_POST['add']['password']);
			unset($_POST['add']['old_password']);
		}else{
			$this->response['text'] = 'Пароль введите';
			return false;
		}
        foreach ($_POST['add'] as $k=>$v) $_POST['add'][$k]=$this->db->esc($v);
        $_POST['add']['type'] = 2;
		if($this->u->add($_POST['add'])){
			$this->response['text'] = 'ok';
			return true;
		}
		$this->response['text'] = 'error';
		return false;
	}

	function editadminAction(){
		$this->view = '';
		if(!empty($_POST['add']['old_password'])){
			if ($this->u->getItem(array(
                'login'=>$this->db->esc($_POST['add']['login']),
                'password'=>md5($_POST['add']['old_password'])))){
				$_POST['add']['password'] = md5($_POST['add']['password']);
			}else{
				$this->response['text'] = 'Неверный пароль';
				return false;
			}
		}else{
			unset($_POST['add']['password']);
		}
		unset($_POST['add']['old_password']);
        foreach ($_POST['add'] as $k=>$v) $_POST['add'][$k]=$this->db->esc($v);
		if ($this->u->update($_POST['id'], $_POST['add'])){
			$this->response['text'] = 'ok';
			return true;
		}
		$this->response['text'] = 'neok2';
		return false;
	}
	
	function getadminAction(){
		$this->view = 'xml';
		$this->layout = false;
		$this->response['item'] = $this->u->getItem(@$_POST['id']);
	}

	function pagesAction(){
		$p = new Pages();
		$pid = (@$this->request['pid'])?(int)$this->request['pid']:0;
		if ($pid){
			$this->response['trail'] = $p->getTrail($pid);
		}
		if (@$this->request['up']){
			$p->up($this->request['up'], $pid);
		}
		if (@$this->request['dn']){
			$p->down($this->request['dn'], $pid);
		}
		$this->response['pages'] = $p->getPagesMenu($pid, ITMP, $this->request['page']);
		foreach ($this->response['pages'] as $k=>$v){
			$this->response['pages'][$k]['count'] = $p->getPagesCount($v['id']);
		}
		$count = $p->getPagesCount($pid);
		if ($count>sizeof($this->response['pages'])){
			$this->response['pager'] = Utils::getPages($count, $this->request['page'],ITMP);
		}
	}

	function pages_addAction(){
		$p = new Pages();
		$pid = (@$this->request['pid'])?(int)$this->request['pid']:0;
		if ($pid){
			$this->response['trail'] = $p->getTrail($pid);
		}
		if (@$this->request['id']){
			$this->response['page'] = $p->getItem($this->request['id']);
		}
		if(@$_POST['save']){
            $_POST['add']['alias'] = htmlspecialchars($_POST['add']['alias']);
            $_POST['add']['title'] = htmlspecialchars($_POST['add']['title']);
            $_POST['add']['keywords'] = htmlspecialchars($_POST['add']['keywords']);
            $_POST['add']['description'] = htmlspecialchars($_POST['add']['description']);
            $_POST['add']['name'] = htmlspecialchars($_POST['add']['name']);
            foreach ($_POST['add'] as $k=>$v) $_POST['add'][$k]=$this->db->esc($v);
			if (@$this->request['id']){
				if (!$p->update($this->request['id'], $_POST['add'])){
					$this->response['text'] = 'error';
					return true;
				}
			}else{
				$_POST['add']['pid'] = $pid;
				if(!$p->add($_POST['add'])){
					$this->response['text'] = 'error';
					return true;
				}
			}
			Utils::redirect('admin/pages'.(($this->request['pid'])?('/pid_'.$pid):''));
		}
	}
	
	function delpageAction(){
		$p = new Pages();
		if ($p->delete($this->request['id'])) exit('ok');
        exit('neok');
	}
	/*************************************************************/
	function settingsAction(){
		include_once (MODEL_DIR . 'Config.class.php');
		$config = new Config();
		if(@$_POST['save']){
			$config->save($_POST['conf']);
			$this->response['ok'] =1;
		}
		$this->response['conf'] = $config->getConfig();
	}
}