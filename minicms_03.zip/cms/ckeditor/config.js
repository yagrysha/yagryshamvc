CKEDITOR.editorConfig = function( config )
{
	 config.language = 'ru';
	 config.uiColor = '#E0EAF3';
     CKEDITOR.config.toolbar_Full =
[
	['Source','-','Save','NewPage','Preview','Maximize','-','Templates'],
	['Cut','Copy','Paste','PasteText','PasteFromWord'],
	['Undo','Redo','-','Find','Replace','-','SelectAll','RemoveFormat'],['Link','Unlink','Anchor'],
	['Image','Flash','Table'],	'/',
	['Bold','Italic','Underline','Strike','Subscript','Superscript'],['Styles','Format','Font','FontSize'],
	['JustifyLeft','JustifyCenter','JustifyRight','JustifyBlock'],['TextColor','BGColor','-','NumberedList','BulletedList','Outdent','Indent']
];
};
