<?php
/**
 * miniMVC 
 * http://mvc.yagrysha.com/
 */
class Sqlite {
	var $dbname = DBNAME;
	var $connection = null;
    var $debug = false;

	function connect(){
		$this->connection = sqlite_open(DATA_DIR.'sqlite/'.$this->dbname, 0666, $sqliteerror);
		if(!$this->connection) Error::fatal($sqliteerror);
	}
	
	function close(){
		sqlite_close($this->connection);
	}

	function getConnection(){
		if ($this->connection == null)	$this->connect();
		return $this->connection;
	}

	function SelectCell($table, $in=array()){
		return @array_pop($this->SelectOne($table, $in));
	}

	function SelectOne($table, $in=array()){
		$in['limit']=1;
		return @array_pop($this->Select($table, $in));
	}

	function Select($table, $in = array(), $index=false){
		if($this->debug) $starttime = Utils::getmicrotime();
		$select = '*';
        if(!empty($in['select'])) {
            if (is_array($in['select'])) {
                $select = '';
                foreach ($in['select'] as $k => $v) $select.= (($select)?'':', ').$v;
            } else $select = $in['select'];
        }
		$params = '';
        if(!empty($in['where']))
   		if(is_array($in['where'])){
			$params = array();
			foreach($in['where'] as $k=>$v)	$params[$k] = $k."='$v'";
			$params = ' WHERE '.implode(' AND ', $params);
		}else $params = ' WHERE '.$in['where'];
		if(!empty($in['_xtra'])){
			$params .= ' '.$in['_xtra'];
		}
		$limit = '';
        if (!empty($in['limit']['to'])) {
            $to = (int) $in['limit']['to'];
            if (!empty($in['limit']['page'])) {
                $from = $in['limit']['page'] * $to - $to;
            } else {
                $from = isset($in['limit']['from'])?$in['limit']['from']:0;
            }
            $limit = ' LIMIT ' . $from . ',' . $to;
        } elseif (!empty($in['limit'])) {
            $limit = ' LIMIT ' . (int) $in['limit'];
        }
		$order = '';
        if(!empty($in['order']))
		if(is_array($in['order'])){
			foreach ($in['order'] as $k=>$v)
				$order.= (($order)?', ':'').$v.' '.$k;
			$order = ' ORDER BY '.$order;
		}else $order = ' ORDER BY '.$in['order'];

		$sql='SELECT '.$select.' FROM '.$table.$params.$order.$limit;
		if($this->debug) echo $sql."<br>\n";
		if(!$result = sqlite_unbuffered_query($this->connection,$sql)){
			if($this->debug) echo sqlite_error_string(sqlite_last_error($this->connection))."<br>\n";
			return false;
		}
		$return = array();
		if($index){
			while ($row = sqlite_fetch_array($result, SQLITE_ASSOC))	$return[$row[$index]] = $row;
		}else{
			while ($row = sqlite_fetch_array($result, SQLITE_ASSOC))	$return[] = $row;
		}
		if($this->debug) echo (Utils::getmicrotime()-$starttime)."<br>\n";
		return $return;
	}

	function sql($sql, $index=false){
		if($this->debug) {
			$starttime = Utils::getmicrotime();
			echo $sql."<br>\n";
		}
		if (!$result = sqlite_unbuffered_query($this->connection,$sql)){
			if($this->debug) echo sqlite_error_string(sqlite_last_error($this->connection))."<br>\n";
			return false;
		}
		$return = array();
		if($index){
			while ($row = sqlite_fetch_array($result, SQLITE_ASSOC))	$return[$row[$index]] = $row;
		}else{
			while ($row = sqlite_fetch_array($result, SQLITE_ASSOC))	$return[] = $row;
		}
		if($this->debug) echo (Utils::getmicrotime()-$starttime)."<br>\n";
		return $return;
	}

	function Delete ($table, $in=null){
		if($this->debug) $starttime = Utils::getmicrotime();
        if (!empty($in)) {
            $sql = 'DELETE FROM ' . $table . ' WHERE ';
            if (is_array($in)) {
                $params = array();
                foreach ($in as $k => $v) $params[$k] = "`$k`='$v'";
                $sql.= implode(' AND ', $params);
            } else $sql.= $in;
        } else $sql = 'TRUNCATE TABLE ' . $table;
		if($this->debug) echo $sql."<br>\n";
		if(sqlite_unbuffered_query($this->connection,$sql)){
			if($this->debug) echo (Utils::getmicrotime()-$starttime)."<br>\n";
			return true;
		}
		if($this->debug) echo sqlite_error_string(sqlite_last_error($this->connection))."<br>\n";
		return false;
	}

	function Insert ($table, $in){
		if($this->debug) $starttime = Utils::getmicrotime();
		$values = array();
		$keys = array();
		foreach($in as $k=>$v){
			$keys[] = $k;
			$values[] = "'$v'";
		}
		$sql='INSERT INTO '.$table.' ('.implode(',', $keys).') VALUES('.implode(',', $values).')';
		if($this->debug) echo $sql."<br>\n";
		if(sqlite_unbuffered_query($this->connection,$sql)){
			if($this->debug) echo (Utils::getmicrotime()-$starttime)."<br>\n";
			return sqlite_last_insert_rowid($this->connection);
		}
		if($this->debug) echo sqlite_error_string(sqlite_last_error($this->connection))."<br>\n";
		return false;
	}

	function InsertArray ($table, $in){
		if($this->debug) $starttime = Utils::getmicrotime();
		$values = array();
		$keys = array();
        $sql = '';
		foreach ($in as $it=>$item){
			foreach($item as $k=>$v){
				if($it==0) $keys[] = $k;
				$values[] = "'$v'";
			}
			$sql.=(($sql)?', ':'').'('.implode(',', $values).')';
		}
        $sql = 'INSERT INTO '.$table.' ('.implode(',', $keys).') VALUES'.$sql;
		if($this->debug) echo $sql."<br>\n";
		if(sqlite_unbuffered_query($this->connection,$sql)){
			if($this->debug) echo (Utils::getmicrotime()-$starttime)."<br>\n";
			return sqlite_last_insert_rowid($this->connection);
		}
		if($this->debug) echo sqlite_error_string(sqlite_last_error($this->connection))."<br>\n";
		return false;
	}

	function Replace ($table, $in){
		if($this->debug) $starttime = Utils::getmicrotime();
		$values = array();
		$keys = array();
		foreach($in as $k=>$v){
			$keys[] = $k;
			$values[] = "'$v'";
		}
		$sql='REPLACE INTO '.$table.' ('.implode(',', $keys).') VALUES('.implode(',', $values).')';
		if($this->debug) echo $sql."<br>\n";
		if(sqlite_unbuffered_query($this->connection,$sql)){
			if($this->debug) echo (Utils::getmicrotime()-$starttime)."<br>\n";
			return sqlite_last_insert_rowid($this->connection);
		}
		if($this->debug) echo sqlite_error_string(sqlite_last_error($this->connection))."<br>\n";
		return false;
	}

	function Update ($table, $set, $where=null){
		if($this->debug) $starttime = Utils::getmicrotime();
		if(is_array($set)){
			$var = array();
			foreach($set as $k=>$v) $var[] = $k."='$v'";
			$var = implode(', ', $var);
		}else $var = $set;
		$params = '';
        if(!empty($where))
		if(is_array($where)){
			$params = array();
			foreach($where as $k=>$v)	$params[$k] = $k."='$v'";
			$params = implode(' AND ', $params);
		}else $params = $where;
		$sql = 'UPDATE '.$table.' SET '.$var.' WHERE '.$params;
		if($this->debug) echo $sql."<br>\n";
		if(sqlite_unbuffered_query($this->connection,$sql)){
			if($this->debug) echo (Utils::getmicrotime()-$starttime)."<br>\n";
			return true;
		}
		if($this->debug) echo sqlite_error_string(sqlite_last_error($this->connection))."<br>\n";
		return false;
	}

    function esc($string){
        return sqlite_escape_string($string);
    }
}