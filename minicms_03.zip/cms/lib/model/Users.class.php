<?php
/**
 * miniCMS
 * http://mvc.yagrysha.com/
 */
class Users extends Item {
	var $table = 'users';
    const T_USER = 1;
    const T_ADMIN =2;
    
	function login($login, $passw){
		$u = $this->db->SelectOne($this->table, 
				array('where'=>'login="'.$this->db->esc($login).
                '" AND password="'.md5($passw).'" AND type>0'));
		if(!$u) return false;
		$_SESSION['user'] = $u;
		$this->update($u['id'], array('last_login'=>time()));
		return $u;
	}

    function add($item){
		if(!isset($item['type']))$item['type'] = 1;
		$item['code'] = md5(uniqid(rand(1, 9), true));
        $item['password'] = md5($item['password']);
		$item['created_at'] = time();
        foreach ($item as $k=>$v) $item[$k]=$this->db->esc($v);
		return parent::add($item);
	}

    function update($id, $item){
        if(isset($item['login']))unset($item['login']);
        if(!empty($item['password']))$item['password'] = md5($item['password']);
        else unset($item['password']);
        foreach ($item as $k=>$v) $item[$k]=$this->db->esc($v);
		return parent::update($id, $item);
	}

	function getByLogin($login){
		return $this->getItem(array('login'=>$this->db->esc($login)));
	}

	function getByEmail($mail){
		return $this->getItem(array('mail'=>$this->db->esc($mail)));
	}
}