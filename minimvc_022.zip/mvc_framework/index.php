<?php
/**
 * miniMVC 0.2.2  29.12.2008
 * @author Yaroslav Gryshanovich <yagrysha@gmail.com>
 * @link http://mvc.yagrysha.com/
 */
define("ROOT_DIR", dirname(__FILE__));
include_once ROOT_DIR	.'/config/conf.php';
error_reporting(ER_REP);
include_once CONFIG_DIR	.'routing.php';	
require_once INC_DIR	.'utils.class.php';
require_once INC_DIR	.'controller.class.php';
include_once INCV_DIR	.'view.class.php';
$db = null;
$version = DEF_VERSION;
$patharray = null;
$app = new Controller();
$app->run();
?>