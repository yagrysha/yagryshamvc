<?php
/**
 * miniMVC 
 * http://mvc.yagrysha.com/
 */
class exampleActions extends Actions {

	var $moduleName = 'example';
	var $u = null;

	function exampleActions(){
		parent::Actions();
		$this->u = new Users();
	}
	
	function indexAction(){
		Utils::redirect('/'.$this->version.'/login.html');
	}

	function loginAction(){
		if(!empty($_POST['login']) && !empty($_POST['password'])){
			$user = $this->u->login($_POST['login'], $_POST['password']);
			if($user){
				$this->user = array_merge($this->user, $user);
				if(@$_POST['saveme']){
					$this->user['conf']['sid']=md5($user['code']);
					$this->user['conf']['id']=$user['id'];
					$this->setCust();
				}
				Utils::redirect('/');
			}
			$this->response['wrong'] = true;
		}
	}

	function logoutAction(){
		unset($_SESSION);
		session_unset();
		session_destroy();
		unset($this->user['conf']['sid']);
		unset($this->user['conf']['id']);
		$this->setCust();
		setcookie(session_name(), "",0 , "/", DOMAIN, 0);
		Utils::redirect('/'.$this->version);
	}
}