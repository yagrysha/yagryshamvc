<?php /* Smarty version 2.6.20, created on 2009-01-11 22:18:41
         compiled from D:%5Cxampp%5Chtdocs%5Cmvc_framework/templates/layout.tpl */ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>miniMVC</title>
<meta name="description" content="minimvc" />
<meta name="keywords" content="" />
<script type="text/javascript" src="/js/prototype.js"></script> 
</head>
<body>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => $this->_tpl_vars['template'], 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
</body>
</html>