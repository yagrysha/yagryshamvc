<?php
/**
 * miniMVC 
 * http://mvc.yagrysha.com/
 */
class Item {
	var $table = null;
	var $db = null;

	function Item(){
		global $app;
		$this->db = $app->db;
		$this->table = DBPREFIX.$this->table;
		if($app->version != DEF_VERSION) $this->table = $app->version.'_'.$this->table;
	}

	function getItems($limit = array(), $where = array(), $select = '', $order = array('desc'=>'id')){
		return $this->db->Select($this->table, 
				array(
						'select'=>$select, 'where'=>$where, 
						'limit'=>$limit, 'order'=>$order));
	}

	function getItem($id){
		if(is_array($id) && sizeof($id) > 0){
			return $this->db->SelectOne($this->table, array('where'=>$id));
		}else{
			return $this->db->SelectOne($this->table, array('where'=>array('id'=>(int)$id)));
		}
	}

	function delete($id){
		return $this->db->Delete($this->table, array('id'=>(int)$id));
	}

	function add($item){
		if(!is_array($item)) return false;
		return $this->db->Insert($this->table, $item);
	}

	function update($id, $set){
		return $this->db->Update($this->table, $set, array('id'=>(int)$id));
	}

	function wupdate($set, $where = array()){
		return $this->db->Update($this->table, $set, $where);
	}

	function getCount($where = array()){
		return $this->db->SelectCell($this->table, array('where'=>$where, 'select'=>'count(*)'));
	}
}