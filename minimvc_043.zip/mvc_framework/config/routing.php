<?php
$routing = array();
$versions = array(
    'en' => 'english',
    'ru' => 'русский'
);