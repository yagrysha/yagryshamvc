<?php
/**
 * miniMVC
 * http://mvc.yagrysha.com/
 */
class Utils {

    function getmicrotime() {
        list($usec, $sec) = explode(" ", microtime());
        return ((float)$usec + (float)$sec);
    }

    function location($url) {
        header('Location: ' . $url);
        exit();
    }

    function redirect($url) {
        header('Location: ' . DOMAIN .ROOT. $url);
        exit();
    }

    function getPages($count, $npage, $onpage = 20, $nn = 10) {
        $lastpage = ceil($count / $onpage);
        $end = ceil($npage / $nn) * $nn;
        $start = $end - ($nn - 1);
        $end = ($end > $lastpage)? $lastpage:$end;
        $pages = array();
        if($start > 1) $pages[$start - 1] = '...';
        for($i = $start; $i <= $end; $i++) {
            $pages[$i] = $i;
        }
        if($end < $lastpage) $pages[$end + 1] = '...';
        return $pages;
    }

    function disabmagquotes() {
        if (get_magic_quotes_gpc()) {
            $process = array(&$_GET, &$_POST, &$_COOKIE, &$_REQUEST);
            while (list($key, $val) = each($process)) {
                foreach ($val as $k => $v) {
                    unset($process[$key][$k]);
                    if (is_array($v)) {
                        $process[$key][stripslashes($k)] = $v;
                        $process[] = &$process[$key][stripslashes($k)];
                    } else {
                        $process[$key][stripslashes($k)] = stripslashes($v);
                    }
                }
            }
            unset($process);
        }
    }
}