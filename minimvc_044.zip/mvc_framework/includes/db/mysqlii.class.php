<?php
/**
 * miniMVC 
 * http://mvc.yagrysha.com/
 */
class Mysqlii {
	var $dbname = DBNAME;
	var $dbhost = DBHOST;
	var $dbuser = DBUSER;
	var $dbpassw = DBPASSW;
	var $connection = null;
	var $debug = false;

	function connect(){
		$this->connection = mysqli_connect($this->dbhost, $this->dbuser, $this->dbpassw) or Error::fatal( 'Could not connect');
		mysqli_select_db($this->connection, $this->dbname) or Error::fatal( 'Could not select database '.$this->dbname);
		if (defined('SET_NAMES')) mysqli_set_charset($this->connection, constant('SET_NAMES'));
	}
	
	function close(){
		mysqli_close($this->connection);
	}

	function getConnection(){
		if ($this->connection == null)	$this->connect();
		return $this->connection;
	}

	function SelectCell($table, $in=array()){
		return @array_pop($this->SelectOne($table, $in));
	}

	function SelectOne($table, $in=array()){
		$in['limit']=1;
		return @array_pop($this->Select($table, $in));
	}

	function Select($table, $in = array(), $index=false){
		if($this->debug) $starttime = Utils::getmicrotime();
		$select = '*';
        if(!empty($in['select'])) {
            if (is_array($in['select'])) {
                $select = '';
                foreach ($in['select'] as $k => $v) $select.= (($select)?'':', ')."`$v`";
            } else $select = $in['select'];
        }

		$params = '';
        if(!empty($in['where']))
   		if(is_array($in['where'])){
			$params = array();
			foreach($in['where'] as $k=>$v)	$params[$k] = "`$k`='$v'";
			$params = ' WHERE '.implode(' AND ', $params);
		}else $params = ' WHERE '.$in['where'];
		if(!empty($in['_xtra'])) $params .= ' '.$in['_xtra'];

		$limit = '';
        if (!empty($in['limit']['to'])) {
            $to = (int) $in['limit']['to'];
            if (!empty($in['limit']['page'])) {
                $from = $in['limit']['page'] * $to - $to;
            } else {
                $from = isset($in['limit']['from'])?$in['limit']['from']:0;
            }
            $limit = ' LIMIT ' . $from . ',' . $to;
        } elseif (!empty($in['limit'])) {
            $limit = ' LIMIT ' . (int) $in['limit'];
        }

		$order = '';
        if(!empty($in['order']))
		if(is_array($in['order'])){
			foreach ($in['order'] as $k=>$v)
				$order.= (($order)?', ':'').$v.' '.$k;
			$order = ' ORDER BY '.$order;
		}else	$order = ' ORDER BY '.$in['order'];
		$sql='SELECT '.$select.' FROM '.$table.$params.$order.$limit;
		if($this->debug) echo $sql."<br>\n";
		if(!$result = mysqli_query($this->connection, $sql)){
			if($this->debug) echo mysqli_error($this->connection)."<br>\n";
			return false;
		}
		$return = array();
		if($index){
			while ($row = mysqli_fetch_assoc($result))	$return[$row[$index]] = $row;
		}else{
			while ($row = mysqli_fetch_assoc($result))	$return[] = $row;
		}
		if($this->debug) echo (Utils::getmicrotime()-$starttime)."<br>\n";
		return $return;
	}

	function sql($sql, $index=false){
		if($this->debug) {
			$starttime = Utils::getmicrotime();
			echo $sql."<br>\n";
		}
		if (!$result = mysqli_query($this->connection, $sql)){
			if($this->debug) echo mysqli_error($this->connection)."<br>\n";
			return false;
		}
        if (is_a($result, 'mysqli_result')) {
            $return = array();
            if ($index) {
                while ($row = mysqli_fetch_assoc($result))
                    $return[$row[$index]] = $row;
            } else {
                while ($row = mysqli_fetch_assoc($result))
                    $return[] = $row;
            }
        } else $return = $result;
		if($this->debug) echo (Utils::getmicrotime()-$starttime)."<br>\n";
		return $return;
	}

	function Delete ($table, $in=null){
		if($this->debug) $starttime = Utils::getmicrotime();
        if (!empty($in)) {
            $sql = 'DELETE FROM ' . $table . ' WHERE ';
            if (is_array($in)) {
                $params = array();
                foreach ($in as $k => $v) $params[$k] = "`$k`='$v'";
                $sql.= implode(' AND ', $params);
            } else $sql.= $in;
        } else $sql = 'TRUNCATE TABLE ' . $table;
        if ($this->debug) echo $sql . "<br>\n";
        if (mysqli_query($this->connection,$sql)){
			if($this->debug) echo (Utils::getmicrotime()-$starttime)."<br>\n";
			return true;
		}
		if($this->debug) echo mysqli_error($this->connection)."<br>\n";
		return false;
	}

	function Insert ($table, $in){
		if($this->debug) $starttime = Utils::getmicrotime();
		$values = array();
		$keys = array();
		foreach($in as $k=>$v){
			$keys[] = "`$k`";
			$values[] = "'$v'";
		}
		$sql='INSERT INTO '.$table.' ('.implode(',', $keys).') VALUES('.implode(',', $values).')';
		if($this->debug) echo $sql."<br>\n";
		if(mysqli_query($this->connection,$sql)){
			if($this->debug) echo (Utils::getmicrotime()-$starttime)."<br>\n";
			return mysqli_insert_id($this->connection);
		}
		if($this->debug) echo mysqli_error($this->connection)."<br>\n";
		return false;
	}

	function InsertArray ($table, $in){
		if($this->debug) $starttime = Utils::getmicrotime();
		$values = array();
		$keys = array();
        $sql = '';
		foreach ($in as $it=>$item){
			foreach($item as $k=>$v){
				if($it==0) $keys[] = "`$k`";
				$values[] = "'$v'";
			}
			$sql.=(($sql)?', ':'').'('.implode(',', $values).')';
		}
		$sql = 'INSERT INTO '.$table.' ('.implode(',', $keys).') VALUES'.$sql;
		if($this->debug) echo $sql.'<br>';
		if(mysqli_query($this->connection,$sql)){
			if($this->debug) echo (Utils::getmicrotime()-$starttime)."<br>\n";
			return mysqli_insert_id($this->connection);
		}
		if($this->debug) echo mysqli_error($this->connection)."<br>\n";
		return false;
	}

	function Replace ($table, $in){
		if($this->debug) $starttime = Utils::getmicrotime();
		$values = array();
		$keys = array();
		foreach($in as $k=>$v){
			$keys[] = "`$k`";
			$values[] = "'$v'";
		}
		$sql='REPLACE INTO '.$table.' ('.implode(',', $keys).') VALUES('.implode(',', $values).')';
		if($this->debug) echo $sql."<br>\n";
		if(mysqli_query($this->connection,$sql)){
			if($this->debug) echo (Utils::getmicrotime()-$starttime)."<br>\n";
			return mysqli_insert_id($this->connection);
		}
		if($this->debug) echo mysqli_error($this->connection)."<br>\n";
		return false;
	}

	function Update ($table, $set, $where=null){
		if($this->debug) $starttime = Utils::getmicrotime();
		if(is_array($set)){
			$var = array();
			foreach($set as $k=>$v)	$var[] = "`$k`='$v'";
			$var = implode(', ', $var);
		}else{
			$var = $set;
		}
		$params = '';
        if(!empty($where))
		if(is_array($where)){
			$params = array();
			foreach($where as $k=>$v){
				$params[$k] = "`$k`='$v'";
			}
			$params = ' WHERE '.implode(' AND ', $params);
		}else{
			$params = ' WHERE '.$where;
		}
		$sql = 'UPDATE '.$table.' SET '.$var.$params;
		if($this->debug) echo $sql."<br>\n";
		if(mysqli_query($this->connection,$sql)){
			if($this->debug) echo (Utils::getmicrotime()-$starttime)."<br>\n";
			return true;
		}
		if($this->debug) echo mysqli_error($this->connection)."<br>\n";
		return false;
	}

    function esc($string){
        return mysqli_real_escape_string($this->connection,$string);
    }
    function autocommit($mode){
        return mysqli_autocommit($this->connection, $mode);
    }
    function commit(){
        return mysqli_commit($this->connection);
    }
    function rollback(){
        return mysqli_rollback($this->connection);
    }
    function transaction(){
        return $this->sql('START TRANSACTION');
    }
}