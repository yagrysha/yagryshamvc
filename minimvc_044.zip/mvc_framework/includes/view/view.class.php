<?php
/**
 * http://mvc.yagrysha.com/
 */
class View {
	var $template;
	var $response;

	function View(&$response){
		$this->response = $response;
	}

	function getView(){
		return isset($this->response['text'])?$this->response['text']:false;
	}

	function display(){
		echo $this->getView();
	}
}