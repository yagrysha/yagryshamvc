<?php
/**
 * miniMVC 
 * http://mvc.yagrysha.com/
 */
class exampleComponents extends Components {
	var $moduleName = 'example';

	function indexAction(){
		include_once (MODEL_DIR . 'Config.class.php');
		$config = new Config();
		print_r($config->getConfig());
		$this->view = '';
	}
}