<?php /* Smarty version 2.6.20, created on 2008-10-08 21:50:41
         compiled from D:%5Cxampp%5Chtdocs%5Cmvc_framework/templates/example/login.tpl */ ?>
<h2 >login</h2>
<?php if ($this->_tpl_vars['wrong']): ?>
<span style="color:red;">Error</span>
<?php endif; ?>
<form action="" method="post">
<table>
<tr><td><strong>login:</strong></td><td><input type="text" name="login"></td></tr>
<tr><td align="right"><strong>Password:</strong></td><td><input type="password" name="password"></td></tr>
<tr><td></td><td><input type="submit" value="Send"></td></tr>
</table>
</form>


</div>