<?php
/**
 * yagrysha@gmail.com
 * Yaroslav Gryshanovich
 * http://mvc.yagrysha.com/
 * 23.10.2008 minimvc 0.2.1
 */
define("ROOT_DIR", dirname(__FILE__));
include_once ROOT_DIR.'/config/conf.php';
include_once CONFIG_DIR.'routing.php';	
error_reporting(ER_REP);
require_once INC_DIR . 'utils.class.php';
require_once INC_DIR.'controller.class.php';
include_once INCV_DIR.'view.class.php';
$db = null;
$version = DEF_VERSION;
$patharray = null;
$app = new Controller();
$app->run();
?>