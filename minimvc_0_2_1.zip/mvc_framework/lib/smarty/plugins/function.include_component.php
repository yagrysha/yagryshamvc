<?php
/**
 * Smarty plugin
 * @package Smarty
 * @subpackage plugins
 */


/**
 * Smarty {include_compjnent} plugin
 *
 * Type:     function<br>
 * Name:     include_component<br>
 * Purpose:  include_component
 * @link 
 * @author Monte Ohrt <monte at ohrt dot com>
 * @param array
 * @param Smarty
 * @return string|null if the assign parameter is passed, Smarty assigns the
 *                     result to a template variable
 */
function smarty_function_include_component($params, &$smarty)
{
    if (empty($params['name'])) {
        $smarty->_trigger_fatal_error("[plugin] parameter 'name' cannot be empty");
        return;
    }
    list($mn, $cn)= explode('/',$params['name']);
    Controller::include_component($mn, $cn, $params, @$params['cacheKey']);
    return $content;

}

/* vim: set expandtab: */

?>
